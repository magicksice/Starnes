(function(){
  const btn = document.querySelector('[data-menu-btn]');
  const nav = document.querySelector('[data-mobile-nav]');
  if(!btn || !nav) return;
  btn.addEventListener('click', () => {
    const isOpen = nav.getAttribute('data-open') === 'true';
    nav.setAttribute('data-open', String(!isOpen));
  });
})();
