(function(){
  const btn = document.querySelector('[data-menu]');
  const mobile = document.querySelector('[data-mobile]');
  if(btn && mobile){
    mobile.style.display = 'none';
    btn.addEventListener('click', ()=>{
      const open = mobile.getAttribute('data-open') === 'true';
      mobile.setAttribute('data-open', String(!open));
      mobile.style.display = open ? 'none' : 'block';
    });
  }
})();