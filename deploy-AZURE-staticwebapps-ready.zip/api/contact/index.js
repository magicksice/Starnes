    module.exports = async function (context, req) {
      try {
        const body = req.body || {};
        if (body["bot-field"]) {
          context.res = { status: 400, body: "Bad Request" };
          return;
        }

        const name = String(body.name || "").trim();
        const email = String(body.email || "").trim();
        const phone = String(body.phone || "").trim();
        const subject = String(body.subject || "Website Contact").trim();
        const message = String(body.message || "").trim();

        if (!name || !email || !message) {
          context.res = { status: 400, body: "Please complete required fields." };
          return;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          context.res = { status: 400, body: "Invalid email." };
          return;
        }

        context.bindings.message = {
          personalizations: [{ to: [{ email: "info@starnessurgical.com" }] }],
          from: { email: "no-reply@starnessurgical.com" },
          subject: `[Website Contact] ${subject}`,
          content: [{
            type: "text/plain",
            value:
`Name: ${name}
Email: ${email}
Phone: ${phone}

Message:
${message}
`
          }]
        };

        context.res = {
          status: 200,
          headers: { "Content-Type": "application/json" },
          body: { ok: true }
        };
      } catch (e) {
        context.log.error(e);
        context.res = { status: 500, body: "Server error" };
      }
    };
